#include <iostream>
using namespace std;
int main()
{
    system("taskmgr.exe");
}